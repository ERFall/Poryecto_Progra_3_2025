/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clinica.service;

import clinica.model.Cita;
import clinica.model.CitaDto;
import clinica.util.AppContext;
import clinica.util.EntityManagerHelper;
import clinica.util.Mensaje;
import javafx.scene.control.Alert;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

/**
 *
 * @author ivann
 */
public class CitaService {
    EntityManager em = EntityManagerHelper.getInstance().getManager();
    private EntityTransaction et;

    public CitaService() {
    }

    public Cita guardarCita(CitaDto citaDto) {
        try {
            et = em.getTransaction();
            et.begin();
            Cita cita = new Cita(citaDto);
            em.persist(cita);
            et.commit();
            em.refresh(cita);
          //  Mensaje.show(Alert.AlertType.INFORMATION, "INFORMACIÓN", "La cita se guardó correctamente.");
            return cita;
        } catch (Exception ex) {
            //et.rollback();
            System.out.println("service:   " + ex);
            //Mensaje.show(Alert.AlertType.ERROR, "ERROR", "Ocurrio un error al guardar la cita.");
            return null;
        }
    }
    public Cita buscarCita(String idCita) {
    try {
        Query qryCita = em.createNamedQuery("Cita.findByIdCita", Cita.class);
        qryCita.setParameter("idCita", idCita.toUpperCase());
        Cita citaEncontrada = (Cita) qryCita.getSingleResult();
        AppContext.getInstance().set("BusquedaCita", citaEncontrada);
        return citaEncontrada;
    } catch (NoResultException ex) {
        Mensaje.show(Alert.AlertType.ERROR, "ERROR", "No existe una cita con el ID ingresado.");
    } catch (NonUniqueResultException ex) {
        Mensaje.show(Alert.AlertType.ERROR, "ERROR", "Ocurrió un error al consultar la cita.");
    } catch (Exception ex) {
        Mensaje.show(Alert.AlertType.ERROR, "ERROR", "Ocurrió un error al consultar la cita.");
    }
    return null;
    
    }
    
    public void eliminarCita(String idCita) {
        try {
            Query qryCita = em.createNamedQuery("Cita.findByIdCita", Cita.class);
            qryCita.setParameter("idCita", idCita.toUpperCase());
            Cita citaEncontrada = (Cita) qryCita.getSingleResult();

            et = em.getTransaction();
            et.begin();
            em.remove(citaEncontrada);
            et.commit();

            Mensaje.show(Alert.AlertType.INFORMATION, "INFORMACIÓN", "La cita se eliminó correctamente.");
        } catch (NoResultException ex) {
            Mensaje.show(Alert.AlertType.ERROR, "ERROR", "No existe una cita con el ID ingresado.");
        } catch (NonUniqueResultException ex) {
            Mensaje.show(Alert.AlertType.ERROR, "ERROR", "Ocurrió un error al consultar la cita.");
        } catch (Exception ex) {
            Mensaje.show(Alert.AlertType.ERROR, "ERROR", "Ocurrió un error al consultar la cita.");
        }
    }
}
