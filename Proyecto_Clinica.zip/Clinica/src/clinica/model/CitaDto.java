/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clinica.model;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javax.persistence.Id;
import java.util.Date;
import java.time.LocalTime;

/**
 *
 * @author maria
 */
public class CitaDto {
    
    private SimpleObjectProperty<Long> citId;
    private SimpleObjectProperty<Date> citFecha;
    private SimpleStringProperty citHora;
    private SimpleObjectProperty<Pacientes> citIdPaciente;
    private SimpleObjectProperty<Medicos> citIdMedico;
    private SimpleStringProperty citDescripcion;
    private SimpleStringProperty citCodigo;
    
    public CitaDto() {
        this.citId = new SimpleObjectProperty<>();
        this.citFecha = new SimpleObjectProperty<>();
        this.citHora = new SimpleStringProperty();
        this.citIdPaciente = new SimpleObjectProperty<>();
        this.citIdMedico = new SimpleObjectProperty<>();
        this.citDescripcion = new SimpleStringProperty();
        this.citCodigo = new SimpleStringProperty();
    }
    public CitaDto(Cita cita) {
        this();
        this.citId.set(cita.getCitId());
        this.citFecha.set(cita.getCitFecha());
        this.citHora.set(cita.getCitHora());
        this.citIdPaciente.set(cita.getCitIdPaciente());
        this.citIdMedico.set(cita.getCitIdMedico());
        this.citDescripcion.set(cita.getCitDescripcion());
        this.citCodigo.set(cita.getCitCodigo());
    }
    public Long getCitId() {
        return citId.get();
    }
    public void setCitId(Long citId) {
        this.citId.set(citId);
    }

    public Date getCitFecha() {
        return citFecha.get();
    }

    public void setCitFecha(Date citFecha) {
        this.citFecha.set(citFecha);
    }

    public String getCitHora() {
        return citHora.get();
    }

    public void setCitHora(String citHora) {
        this.citHora.set(citHora);
    }

    public Pacientes getCitIdPaciente() {
        return citIdPaciente.get();
    }

    public void setCitIdPaciente(Pacientes citIdPaciente) {
        this.citIdPaciente.set(citIdPaciente);
    }

    public Medicos getCitIdMedico() {
        return citIdMedico.get();
    }

    public void setCitIdMedico(Medicos citIdMedico) {
        this.citIdMedico.set(citIdMedico);
    }

    public String getCitDescripcion() {
        return citDescripcion.get();
    }

    public void setCitDescripcion(String citDescripcion) {
        this.citDescripcion.set(citDescripcion);
    }

    public String getCitCodigo() {
        return citCodigo.get();
    }

    public void setCitCodigo(String citCodigo) {
        this.citCodigo.set(citCodigo);
    }   
    
}
