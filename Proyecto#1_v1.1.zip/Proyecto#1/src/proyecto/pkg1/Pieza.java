/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.pkg1;

/**
 *
 * @author Admin
 */

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 * Clase abstracta que representa una pieza de ajedrez.
 * Sirve como superclase para Peon, Torre, etc.
 */
public abstract class Pieza {
    protected String color;  // "blanco" o "negro"

    public Pieza(String color) {
        this.color = color.toLowerCase();
    }

    public String getColor() {
        return color;
    }

    /**
     * Verifica si el movimiento desde una casilla inicial a una final es válido para la pieza.
     *
     * @param fInicio fila de origen
     * @param cInicio columna de origen
     * @param fFin fila de destino
     * @param cFin columna de destino
     * @return true si el movimiento es válido según la lógica de la pieza
     */
    public abstract boolean movimientoValido(int fInicio, int cInicio, int fFin, int cFin);

    /**
     * Devuelve la imagen asociada a esta pieza.
     *
     * @return objeto Image con el ícono de la pieza
     */
    public abstract Image getImagen();

    /**
     * Devuelve una ImageView lista para colocar en el tablero.
     *
     * @return ImageView con la imagen escalada de la pieza
     */
    public ImageView getImageView() {
        ImageView iv = new ImageView(getImagen());
        iv.setFitWidth(60); // ajustar según tamaño de celda
        iv.setFitHeight(60);
        return iv;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + " (" + color + ")";
    }
}