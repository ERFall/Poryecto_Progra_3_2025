/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.pkg1;

/**
 *
 * @author Admin
 */
import javafx.scene.image.Image;

/**
 * Clase que representa un peón del ajedrez.
 * Puede moverse hacia adelante y capturar en diagonal.
 */
public class Peon extends Pieza {
    private boolean primerMovimiento = true;

    public Peon(String color) {
        super(color);
    }

    @Override
    public boolean movimientoValido(int fInicio, int cInicio, int fFin, int cFin) {
        int direccion = color.equals("blanco") ? -1 : 1;
        int avance = fFin - fInicio;

        if (cInicio == cFin) {
            // Movimiento hacia adelante
            if (avance == direccion || (primerMovimiento && avance == 2 * direccion)) {
                primerMovimiento = false;
                return true;
            }
        } else if (Math.abs(cFin - cInicio) == 1 && avance == direccion) {
            // Captura en diagonal
            return true;
        }

        return false;
    }

    @Override
    public Image getImagen() {
        // Usar una ruta absoluta al recurso (desde src)
         String ruta = "/proyecto/pkg1/imagenes/peon_" + color + ".png";
        return new Image(getClass().getResourceAsStream(ruta));
    }
}

