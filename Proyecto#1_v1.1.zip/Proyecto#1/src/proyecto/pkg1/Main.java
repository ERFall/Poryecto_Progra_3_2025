package proyecto.pkg1;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        // Cargamos la pantalla de inicio donde se ingresan nombres y colores
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));

        // Creamos la escena y la mostramos
        Scene scene = new Scene(root);
        stage.setTitle("Ajedrez FX - Inicio");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

