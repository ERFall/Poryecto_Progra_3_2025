/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.pkg1;

/**
 *
 * @author Admin
 */
import java.io.InputStream;
import javafx.scene.image.Image;

/**
 * Clase que representa una Torre del ajedrez.
 * Puede moverse en línea recta horizontal o vertical.
 */
public class Torre extends Pieza {

    public Torre(String color) {
        super(color);
    }

    @Override
    public boolean movimientoValido(int fInicio, int cInicio, int fFin, int cFin) {
        // Movimiento válido si se mueve en línea recta (fila o columna)
        return fInicio == fFin || cInicio == cFin;
    }

    @Override
    public Image getImagen() {
        InputStream is = getClass().getResourceAsStream("/proyecto/pkg1/imagenes/torre.png");
        if (is == null) {
            System.err.println("No se pudo cargar la imagen de Torre, usando imagen por defecto.");
            // Imagen por defecto en línea (puedes cambiar la URL por otra imagen)
            return new Image("https://upload.wikimedia.org/wikipedia/commons/4/4b/Chess_rdt60.png");
        }
        return new Image(is);
    }
}   
