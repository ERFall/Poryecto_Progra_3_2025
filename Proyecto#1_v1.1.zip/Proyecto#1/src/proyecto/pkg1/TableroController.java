/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package proyecto.pkg1;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.image.*;
import proyecto.pkg1.Pieza;
import proyecto.pkg1.Torre;
import proyecto.pkg1.Peon;

public class TableroController {

    @FXML private Label lblJugadorBlancas;
    @FXML private Label lblJugadorNegras;
    @FXML private GridPane gridTablero;
    @FXML private FlowPane piezasCapturadasBlancas;
    @FXML private FlowPane piezasCapturadasNegras;

    private String colorJugador1;

    private final int TAM = 8; // 8x8

    // Método que recibe los datos del formulario inicial
    public void setJugadores(String j1, String j2, String color) {
        colorJugador1 = color;
        if (color.equals("Blancas")) {
            lblJugadorBlancas.setText("Blancas: " + j1);
            lblJugadorNegras.setText("Negras: " + j2);
        } else {
            lblJugadorNegras.setText("Negras: " + j1);
            lblJugadorBlancas.setText("Blancas: " + j2);
        }

        inicializarTablero();
    }

    // Inicializa las piezas del tablero
    private void inicializarTablero() {
        gridTablero.getChildren().clear();

        for (int fila = 0; fila < TAM; fila++) {
            for (int col = 0; col < TAM; col++) {
                StackPane celda = new StackPane();
                celda.setPrefSize(60, 60);
                String color = (fila + col) % 2 == 0 ? "#ffffff" : "#888888";
                celda.setStyle("-fx-background-color: " + color + ";");
                gridTablero.add(celda, col, fila);

                // Agregar piezas en posiciones iniciales (peones y torres)
                if (fila == 1) {
                    agregarPieza(celda, new Peon("negro"), col, fila);
                } else if (fila == 6) {
                    agregarPieza(celda, new Peon("blanco"), col, fila);
                } else if (fila == 0 && (col == 0 || col == 7)) {
                    agregarPieza(celda, new Torre("negro"), col, fila);
                } else if (fila == 7 && (col == 0 || col == 7)) {
                    agregarPieza(celda, new Torre("blanco"), col, fila);
                }
            }
        }
    }

    // Agrega una pieza al StackPane
    private void agregarPieza(StackPane celda, Pieza pieza, int col, int fila) {
        ImageView img = new ImageView(pieza.getImagen());
        img.setFitWidth(50);
        img.setFitHeight(50);

        // Aquí puedes agregar drag-and-drop y resaltado luego
        celda.getChildren().add(img);
    }
}
