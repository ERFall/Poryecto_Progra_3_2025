/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package proyecto.pkg1;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class FXMLDocumentController {

    @FXML private TextField txtJugador1;
    @FXML private TextField txtJugador2;
    @FXML private RadioButton rbBlancas;
    @FXML private RadioButton rbNegras;

    @FXML
    private void iniciarJuego() {
        try {
            // Cargamos el FXML del tablero
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Tablero.fxml"));
            Parent root = loader.load();

            // Enviamos los nombres y colores al controlador del tablero
            TableroController controlador = loader.getController();
            controlador.setJugadores(txtJugador1.getText(), txtJugador2.getText(),
                    rbBlancas.isSelected() ? "Blancas" : "Negras");

            // Creamos una nueva escena para mostrar el tablero
            Stage stage = new Stage();
            stage.setTitle("Tablero de Ajedrez");
            stage.setScene(new Scene(root));
            stage.show();

            // Cerramos la ventana de inicio
            ((Stage) txtJugador1.getScene().getWindow()).close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
